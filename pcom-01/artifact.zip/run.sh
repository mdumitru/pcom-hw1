#!/bin/bash

false
cd sol/
make
cd ..
ln -fs sol/router router

sudo fuser -k 6653/tcp
sudo python3 ./topo.py tests
